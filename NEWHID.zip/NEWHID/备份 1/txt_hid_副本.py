#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
txt_hid.py

功能: 将精简文本格式(.txt)转换为v3版自定义HID二进制(.hid)，
     采用极限压缩 & 极速读写的新格式说明(见题目)。
用法:
    python txt_hid.py <input.txt> <output.hid>
"""

import sys
import struct
from collections import defaultdict

try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

def parse_txt_compact(lines):
    """
    解析精简文本格式，返回内部结构:
    {
      'ntrks': int,
      'division': int,
      'tracks': [ [evt,...], ... ],
      'tempos': [(abs_t, bpm), ...]
    }
    """
    out = {
        'ntrks': 0,
        'division': 480,
        'tracks': [],
        'tempos': []
    }
    current_track = []
    tracks = []
    channel_states = {}
    track_index = -1
    current_channel = None
    tempo_list = []

    def ensure_channel_state(ch):
        if ch not in channel_states:
            channel_states[ch] = {
                'abs_t': 0,
                'last_type': None,
                'last_params': {}
            }
        return channel_states[ch]

    for line in lines:
        if line.startswith("HEADER"):
            # HEADER 0 <nTracks> <division>
            parts = line.split()
            n_ = int(parts[2])
            div_ = int(parts[3])
            out['ntrks'] = n_
            out['division'] = div_
            continue
        
        if line.startswith("TEMPO"):
            # TEMPO <abs_t> <bpm>
            sp = line.split()
            if len(sp) == 3:
                abs_t = int(sp[1])
                bpm = float(sp[2])
                tempo_list.append((abs_t, bpm))
            continue
        
        if line.startswith("TRACK"):
            track_index += 1
            if current_track:
                tracks.append(current_track)
            current_track = []
            channel_states = {}
            current_channel = None
            continue
        
        if line == "END_TRACK":
            if current_track:
                tracks.append(current_track)
            current_track = []
            continue
        
        if line == "END_OF_FILE":
            break
        
        if line.startswith("CH "):
            # CH <channel>
            current_channel = int(line.split()[1])
            ensure_channel_state(current_channel)
            continue
        
        if line == "CH_META_SYSEX":
            # meta或sysex统一视为channel=0xFF
            current_channel = 0xFF
            ensure_channel_state(current_channel)
            continue
        
        if line == "END_CH":
            current_channel = None
            continue
        
        if line.startswith("T"):
            # T<dt> ...
            parts = line.split(maxsplit=1)
            dt = int(parts[0][1:])
            remainder = parts[1].strip() if len(parts) > 1 else ""
            
            if current_channel is None:
                current_channel = 0
                ensure_channel_state(current_channel)
            
            st = ensure_channel_state(current_channel)
            st['abs_t'] += dt
            abs_t = st['abs_t']
            
            last_type = st['last_type']
            last_params = dict(st['last_params'])
            
            if not remainder:
                cur_type = last_type
                cur_params = last_params
            else:
                tokens = remainder.split()
                possible_type = tokens[0].upper()
                known_evt = ("N","CC","PC","POLY_AT","CH_AFTER","PW")
                
                if (possible_type in known_evt or
                    possible_type.startswith("META_0X") or
                    possible_type.startswith("SYSEX") or
                    possible_type.startswith("UNKNOWN_0X")):
                    cur_type = possible_type
                    param_tokens = tokens[1:]
                else:
                    cur_type = last_type
                    param_tokens = tokens

                cur_params = dict(last_params)
                # 解析参数
                for tk in param_tokens:
                    if tk[0] in ('N','V','D'):
                        val = tk[1:]
                        if val.lstrip("+-").isdigit():
                            cur_params[tk[0]] = int(val)
            
            st['last_type'] = cur_type
            st['last_params'] = cur_params
            
            evt = build_evt_from_txt(cur_type, cur_params)
            if evt is not None:
                evt['channel'] = current_channel
                evt['abs_t'] = abs_t
                current_track.append(evt)

    # 收尾
    if current_track:
        tracks.append(current_track)

    if out['ntrks'] == 0:
        out['ntrks'] = len(tracks)
    
    # 将每轨 abs_t -> delta
    final_tracks = []
    for trk in tracks:
        trk.sort(key=lambda x: x['abs_t'])
        out_ev = []
        last_t = 0
        for e in trk:
            dt = e['abs_t'] - last_t
            last_t = e['abs_t']
            e2 = e.copy()
            e2['delta'] = dt
            out_ev.append(e2)
        final_tracks.append(out_ev)
    out['tracks'] = final_tracks

    if len(out['tracks']) == 0:
        out['tracks'].append([])
        out['ntrks'] = 1
    
    out['tempos'] = tempo_list
    out['division'] = max(1, out['division'])
    return out

def build_evt_from_txt(evt_type, params):
    """
    根据精简文本行的事件类型与参数，转为内部统一结构(通道事件)。
    """
    evt = {}
    if evt_type == "N":
        note = params.get('N', 0)
        vel  = params.get('V', 0)
        dur  = params.get('D', 0)
        evt['type_code'] = 0xB0  # 自定义的区分：Note
        evt['note'] = note
        evt['velocity'] = vel
        evt['duration'] = dur
    elif evt_type == "CC":
        evt['type_code'] = 0xB1
        evt['cc_num'] = params.get('N', 0)
        evt['cc_val'] = params.get('V', 0)
    elif evt_type == "PC":
        evt['type_code'] = 0xB2
        evt['pc_num'] = params.get('N', 0)
    elif evt_type == "POLY_AT":
        evt['type_code'] = 0xB3
        evt['note'] = params.get('N', 60)
        evt['pressure'] = params.get('V', 0)
    elif evt_type == "CH_AFTER":
        evt['type_code'] = 0xB4
        evt['pressure'] = params.get('N', 0)
    elif evt_type == "PW":
        evt['type_code'] = 0xB5
        lsb_ = params.get('N', 0) & 0x7F
        msb_ = params.get('V', 0) & 0x7F
        val = (msb_ << 7) | lsb_
        evt['pitch'] = val
    else:
        # meta / sysex等不处理
        return None
    return evt

def build_hid_v3(hid_struct):
    """
    1) 自动判断 packed_div_shift (0~2)
    2) 生成每轨事件(32bit)数组
    3) 若支持zstd则flags.bit2=1，否则0
    4) 末尾写 tempo 块(并把 tempo_count 放在最后2字节，与 hid_txt.py 对齐)
    """
    # 1. 确定 shift
    max_val = 0
    for trk in hid_struct['tracks']:
        for e in trk:
            if e['type_code'] == 0xB0:  # Note
                d = e['duration']
                if d > max_val:
                    max_val = d
            dt = e['delta']
            if dt > max_val:
                max_val = dt
    shift = 0
    if max_val > 1023:
        shift = 1
        if max_val > 2047:
            shift = 2

    # 2. 压缩标志
    use_zstd = 1 if HAS_ZSTD else 0
    flags = (shift & 0x3) | (use_zstd << 2)

    # 3. 文件头(8字节)
    ntrks = hid_struct['ntrks']
    division = hid_struct['division']
    header = bytearray(8)
    header[0:3] = b'HID'
    header[3] = 0x03  # v3
    header[4] = ntrks & 0xFF
    struct.pack_into(">H", header, 5, division)
    header[7] = flags

    # 4. 写每轨数据
    track_bytes_list = []
    for trk_idx, events in enumerate(hid_struct['tracks']):
        v3_words = encode_track_to_v3(events, shift)
        raw_32 = pack_u32_be_array(v3_words)
        if use_zstd == 1 and len(raw_32) > 0:
            cctx = zstd.ZstdCompressor(level=3)
            cdata = cctx.compress(raw_32)
            track_data = bytes([0x7A]) + cdata
        else:
            track_data = raw_32
        track_bytes_list.append(track_data)

    body = b"".join(track_bytes_list)

    # 5. tempo块（将 tempo_count 写在最后2字节）
    tempos = sorted(hid_struct.get('tempos', []), key=lambda x: x[0])
    tempo_count = len(tempos)
    tempo_block_size = 8 * tempo_count + 2  # 先写若干tempo，然后最后2字节是tempo_count
    tempo_block = bytearray(tempo_block_size)
    offset_ = 0
    # 先写每个 (abs_t, mpqn)
    for (abs_t, bpm) in tempos:
        struct.pack_into(">I", tempo_block, offset_, abs_t)
        offset_ += 4
        mpqn = int(round(60000000.0 / bpm))
        mpqn = max(1, mpqn)
        struct.pack_into(">I", tempo_block, offset_, mpqn)
        offset_ += 4
    # 最后写 tempo_count
    struct.pack_into(">H", tempo_block, offset_, tempo_count)

    return bytes(header) + body + tempo_block

def encode_track_to_v3(events, shift):
    """
    将单轨事件列表转为 32bit 整数列表(含Bundle打包)。
    """
    # step0: 先转“逻辑事件”
    logic_events = []
    for e in events:
        dt = e['delta'] >> shift
        ch = e['channel'] & 0x0F
        tc = e['type_code']
        if tc == 0xB0:  # Note
            logic_events.append({
                'dt': dt, 'type': 'Note',
                'ch': ch,
                'note': e['note'] & 0x7F,
                'vel': e['velocity'] & 0x7F,
                'extra': (e['duration'] >> shift) & 0x3FF
            })
        elif tc == 0xB1:  # CC
            logic_events.append({
                'dt': dt, 'type': 'CC',
                'ch': ch,
                'note': e['cc_num'] & 0x7F,
                'vel': 0,
                'extra': e['cc_val'] & 0x3FF
            })
        elif tc == 0xB2:  # PC
            logic_events.append({
                'dt': dt, 'type': 'PC',
                'ch': ch,
                'note': 0,
                'vel': 0,
                'extra': e['pc_num'] & 0x3FF
            })
        elif tc == 0xB3:  # PolyAT
            logic_events.append({
                'dt': dt, 'type': 'PolyAT',
                'ch': ch,
                'note': e['note'] & 0x7F,
                'vel': 0,
                'extra': e['pressure'] & 0x3FF
            })
        elif tc == 0xB4:  # ChAfter
            logic_events.append({
                'dt': dt, 'type': 'ChAfter',
                'ch': ch,
                'note': 0,
                'vel': 0,
                'extra': e['pressure'] & 0x3FF
            })
        elif tc == 0xB5:  # PitchBend
            val = e['pitch'] & 0x3FFF
            logic_events.append({
                'dt': dt, 'type': 'PitchBend',
                'ch': ch,
                'note': 0,
                'vel': 0,
                'extra': val
            })
        else:
            # 不处理meta
            pass

    # step1: 把dt拆成多个 Delay(0x0)
    raw_events = []
    for ev in logic_events:
        dt = ev['dt']
        while dt > 1023:
            raw_events.append(make_v3_word(0x0, ev['ch'], 0, 0, 1023))
            dt -= 1023
        if dt > 0:
            raw_events.append(make_v3_word(0x0, ev['ch'], 0, 0, dt))
        # 输出通道事件
        raw_events.extend(encode_logic_event(ev))

    # step2: 合并Bundle(0x8) —— 在 bundle_header 的 note 字段保存“子类型”
    packed_events = []
    i = 0
    while i < len(raw_events):
        w = raw_events[i]
        et = (w >> 28) & 0xF
        if et in (0x2, 0x3, 0x7):
            chx = (w >> 24) & 0xF
            # 记录这是哪种子事件
            sub_type = et
            candidate = [w]
            j = i + 1
            while j < len(raw_events):
                w2 = raw_events[j]
                et2 = (w2 >> 28) & 0xF
                ch2 = (w2 >> 24) & 0xF
                if et2 != sub_type or ch2 != chx:
                    break
                candidate.append(w2)
                if len(candidate) >= 16:  # 最多16条
                    break
                j += 1
            n_cand = len(candidate)
            if n_cand == 1:
                # 不打包
                packed_events.append(w)
                i += 1
            else:
                # 打包
                bundle_header = make_v3_word(
                    0x8,           # event_type=0x8 (Bundle)
                    chx,
                    sub_type,      # 把子类型存在 note 字段
                    0,
                    n_cand - 1
                )
                packed_events.append(bundle_header)

                # 写 n_cand * 3 字节
                sub_bytes = bytearray(3 * n_cand)
                pos_ = 0
                for wsub in candidate:
                    note7 = (wsub >> 17) & 0x7F
                    vel7  = (wsub >> 10) & 0x7F
                    ex10  = wsub & 0x3FF
                    val24 = (note7 << 17) | (vel7 << 10) | ex10
                    sub_bytes[pos_]   = (val24 >> 16) & 0xFF
                    sub_bytes[pos_+1] = (val24 >> 8) & 0xFF
                    sub_bytes[pos_+2] = val24 & 0xFF
                    pos_ += 3
                packed_events.append(sub_bytes)
                i += n_cand
        else:
            packed_events.append(w)
            i += 1

    return packed_events

def encode_logic_event(ev):
    """
    将单个逻辑事件转为1或2个32bit words(如PitchBend需 0x7 + 0xF)。
    """
    t = ev['type']
    ch = ev['ch']
    note = ev['note'] & 0x7F
    vel = ev['vel'] & 0x7F
    ex = ev['extra'] & 0x3FF

    if t == 'Note':
        w = make_v3_word(0x2, ch, note, vel, ex)
        return [w]
    elif t == 'CC':
        w = make_v3_word(0x3, ch, note, 0, ex)
        return [w]
    elif t == 'PC':
        w = make_v3_word(0x4, ch, 0, 0, ex)
        return [w]
    elif t == 'PolyAT':
        w = make_v3_word(0x5, ch, note, 0, ex)
        return [w]
    elif t == 'ChAfter':
        w = make_v3_word(0x6, ch, 0, 0, ex)
        return [w]
    elif t == 'PitchBend':
        low10 = ex & 0x3FF
        high4 = (ex >> 10) & 0xF
        w1 = make_v3_word(0x7, ch, 0, 0, low10)
        w2 = make_v3_word(0xF, ch, 0, 0, high4)
        return [w1, w2]
    else:
        return []

def make_v3_word(event_type, ch, note, vel, extra):
    return ((event_type & 0xF) << 28) | ((ch & 0xF) << 24) \
           | ((note & 0x7F) << 17) | ((vel & 0x7F) << 10) \
           | (extra & 0x3FF)

def pack_u32_be_array(words):
    """
    将 [int(32bit), bytearray(...), int(32bit), ...] 拼成大端bytes。
    """
    out = bytearray()
    for w in words:
        if isinstance(w, int):
            out += struct.pack(">I", w)
        elif isinstance(w, (bytes, bytearray)):
            out += w
        else:
            raise TypeError("pack_u32_be_array: 不支持的元素类型")
    return bytes(out)

def txt_to_hid_v3(txt_in, hid_out):
    with open(txt_in, "r", encoding="utf-8") as f:
        lines = [ln.strip() for ln in f if ln.strip()]
    hid_struct = parse_txt_compact(lines)
    data = build_hid_v3(hid_struct)
    with open(hid_out, "wb") as f:
        f.write(data)
    print(f"{txt_in} => {hid_out} 转换完成 (v3 HID, 含BPM信息)")

def main():
    if len(sys.argv) != 3:
        print("用法:")
        print("  python txt_hid.py <input.txt> <output.hid>")
        sys.exit(1)
    inp, outp = sys.argv[1], sys.argv[2]
    txt_to_hid_v3(inp, outp)

if __name__ == "__main__":
    main()