#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
hid_txt.py

功能: 将 v3版自定义HID二进制(.hid) 转换回精简文本格式(.txt)。
     兼容无损互转，包括 Bundle(0x8) 拆包、PitchBend(0x7+0xF) 等。
用法:
    python hid_txt.py <input.hid> <output.txt>
"""

import sys
import struct

try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

def parse_hid_v3(data):
    """
    解析HID v3格式，支持:
      - 单轨(ntrks=1)
      - use_zstd=1时(文件头 flags.bit2=1)，若轨道区首字节=0x7A => 需解压
      - 读事件: 普通 4字节大端(Delay/Note/CC/...)，或 0x8 Bundle (extra+1)*3字节
      - PitchBend(0x7 + 0xF) 合并
      - 末尾 tempo 块( [若干 (abs_t, mpqn)], + 2字节 tempo_count )
    返回结构:
      {
        'ntrks': ...,
        'division': ...,
        'shift': ...,
        'tracks': [ [evt, evt, ...] ],
        'tempos': [(abs_t, bpm), ...]
      }
    """
    # 1) 检查文件头
    if len(data) < 8 or data[:3] != b'HID':
        raise ValueError("文件头不合法, 非'HID'开头")
    version = data[3]
    if version != 0x03:
        raise ValueError(f"版本号不符, 需要v3, 读到{version}")

    ntrks = data[4]
    division = struct.unpack(">H", data[5:7])[0]
    flags = data[7]

    shift = flags & 0x3            # 低2bit => shift
    use_zstd = (flags >> 2) & 0x1  # 第3bit => zstd压缩标志

    if ntrks != 1:
        print("[警告] 目前只实现单轨解析, ntrks>1 可能解析不完整")

    # 2) 从文件末尾读 tempo_count
    if len(data) < 10:
        raise ValueError("文件过短, 不含 tempo 块")
    # 末尾2字节 => tempo_count
    tempo_count = struct.unpack(">H", data[-2:])[0]
    # tempo 块大小 = 8*tempo_count + 2
    tempo_block_size = 8 * tempo_count + 2
    if tempo_block_size > (len(data) - 8):
        raise ValueError("tempo块尺寸异常")

    tempo_block_offset = len(data) - tempo_block_size

    # 3) 轨道区在 [8, tempo_block_offset)
    track_region = data[8 : tempo_block_offset]

    # 若 use_zstd=1 且首字节=0x7A，则先解压
    if use_zstd == 1 and len(track_region) > 0 and track_region[0] == 0x7A:
        cdata = track_region[1:]
        if not HAS_ZSTD:
            raise RuntimeError("文件包含Zstd压缩数据, 但未安装 zstandard 库!")
        dctx = zstd.ZstdDecompressor()
        track_decompressed = dctx.decompress(cdata)
    else:
        track_decompressed = track_region

    # 4) 解析轨道事件
    events = decode_track_data(track_decompressed, shift)

    # 5) 解析 tempo 块
    tempos = []
    offset_t = tempo_block_offset
    # 先读 tempo_count 前面的 8*tempo_count字节 => (abs_t, mpqn) * tempo_count
    read_size = 8 * tempo_count
    idx_t = offset_t
    for _ in range(tempo_count):
        abs_t = struct.unpack(">I", data[idx_t : idx_t+4])[0]
        idx_t += 4
        mpqn = struct.unpack(">I", data[idx_t : idx_t+4])[0]
        idx_t += 4
        if mpqn < 1:
            mpqn = 1
        bpm = 60000000.0 / mpqn
        tempos.append((abs_t, bpm))

    # 最后2字节就是 tempo_count，本处已读过

    return {
        'ntrks': ntrks,
        'division': division,
        'shift': shift,
        'tracks': [events],
        'tempos': tempos
    }

def decode_track_data(track_bytes, shift):
    """
    逐字节解析轨道区(已解压后):
      - 4字节 => (event_type, ch, note, vel, extra)
      - event_type=0x8(Bundle) => (extra+1)*3 字节
      - event_type=0x7 + 下一个0xF => 组合成PitchBend
      - Delay(0x0) => abs_t += extra
      - Note/CC/PC/PolyAT/ChAfter/PitchBend => 记录事件
      - Bundle里再看“bundle_sub_type” (记在 header 的 note 字段) 确定子事件解析
    """
    idx = 0
    length = len(track_bytes)
    abs_t = 0
    events = []

    while idx + 4 <= length:
        w = struct.unpack_from(">I", track_bytes, idx)[0]
        idx += 4

        et = (w >> 28) & 0xF
        ch = (w >> 24) & 0xF
        note = (w >> 17) & 0x7F
        vel  = (w >> 10) & 0x7F
        ex   = w & 0x3FF

        if et == 0x0:  # Delay
            abs_t += ex
            continue

        elif et == 0x1:  # Tie(不常用) => 此处暂不处理
            continue

        elif et == 0x2:  # Note
            events.append({
                'abs_t': abs_t,
                'type': 'Note',
                'channel': ch,
                'note': note,
                'velocity': vel,
                'duration': ex
            })

        elif et == 0x3:  # CC
            events.append({
                'abs_t': abs_t,
                'type': 'CC',
                'channel': ch,
                'cc_num': note,
                'cc_val': ex
            })

        elif et == 0x4:  # PC
            events.append({
                'abs_t': abs_t,
                'type': 'PC',
                'channel': ch,
                'pc_num': ex
            })

        elif et == 0x5:  # PolyAT
            events.append({
                'abs_t': abs_t,
                'type': 'PolyAT',
                'channel': ch,
                'note': note,
                'pressure': ex
            })

        elif et == 0x6:  # ChAfter
            events.append({
                'abs_t': abs_t,
                'type': 'ChAfter',
                'channel': ch,
                'pressure': ex
            })

        elif et == 0x7:
            # PitchBend低10bit => 下一个必须是0xF 扩展槽
            if idx + 4 <= length:
                w2 = struct.unpack_from(">I", track_bytes, idx)[0]
                et2 = (w2 >> 28) & 0xF
                ex2 = w2 & 0x3FF
                if et2 == 0xF:
                    idx += 4
                    high4 = ex2 & 0xF
                    val14 = (high4 << 10) | ex
                    events.append({
                        'abs_t': abs_t,
                        'type': 'PitchBend',
                        'channel': ch,
                        'pitch': val14
                    })
                else:
                    raise ValueError("PitchBend后未匹配0xF扩展槽")
            else:
                raise ValueError("PitchBend后数据不足")

        elif et == 0x8:
            # Bundle => extra+1 条子事件，每条3字节
            n_bundle = ex + 1
            needed = 3 * n_bundle
            if idx + needed > length:
                raise ValueError("Bundle后数据不足, 无法读取子包")

            # 关键：note字段存了“bundle_sub_type” (0x2=Note, 0x3=CC, 0x7=PB)
            bundle_sub_type = note  

            sub_data = track_bytes[idx : idx+needed]
            idx += needed
            sub_idx = 0

            for _ in range(n_bundle):
                b1 = sub_data[sub_idx]
                b2 = sub_data[sub_idx+1]
                b3 = sub_data[sub_idx+2]
                sub_idx += 3
                val24 = (b1 << 16) | (b2 << 8) | b3
                note7 = (val24 >> 17) & 0x7F
                vel7  = (val24 >> 10) & 0x7F
                ex10  = val24 & 0x3FF

                if bundle_sub_type == 0x2:
                    # Note
                    events.append({
                        'abs_t': abs_t,
                        'type': 'Note',
                        'channel': ch,
                        'note': note7,
                        'velocity': vel7,
                        'duration': ex10
                    })
                elif bundle_sub_type == 0x3:
                    # CC
                    events.append({
                        'abs_t': abs_t,
                        'type': 'CC',
                        'channel': ch,
                        'cc_num': note7,
                        'cc_val': ex10
                    })
                elif bundle_sub_type == 0x7:
                    # PitchBend(默认高4bit=0)
                    events.append({
                        'abs_t': abs_t,
                        'type': 'PitchBend',
                        'channel': ch,
                        'pitch': ex10
                    })
                else:
                    raise ValueError(f"未知的bundle子事件类型 {bundle_sub_type}")

        else:
            # 0x9..0xE(除0xF) 不支持
            # 0xF 若非PitchBend扩展，也不处理
            continue

    # shift 还原
    for ev in events:
        ev['abs_t'] <<= shift
        if ev['type'] == 'Note':
            ev['duration'] <<= shift

    return events

def build_compact_text(hid_struct):
    """
    将解析后结构 => 精简 txt:
       HEADER 0 nTrks division
       TEMPO abs_t bpm
       TRACK 0
         CH 0
           T<delta> <type> ...
         END_CH
       END_TRACK
       END_OF_FILE
    """
    lines = []
    lines.append(f"HEADER 0 {hid_struct['ntrks']} {hid_struct['division']}")

    # TEMPO
    for (abs_t, bpm) in sorted(hid_struct['tempos'], key=lambda x: x[0]):
        lines.append(f"TEMPO {abs_t} {round(bpm, 4)}")

    lines.append("TRACK 0")
    events = hid_struct['tracks'][0]
    sorted_ev = sorted(events, key=lambda x: x['abs_t'])
    prev_t = 0
    output_rows = []

    for ev in sorted_ev:
        dt = ev['abs_t'] - prev_t
        prev_t = ev['abs_t']
        line = f"T{dt}"

        tname = ev['type']
        if tname == 'Note':
            line += f" N N{ev['note']} V{ev['velocity']} D{ev['duration']}"
        elif tname == 'CC':
            line += f" CC N{ev['cc_num']} V{ev['cc_val']}"
        elif tname == 'PC':
            line += f" PC N{ev['pc_num']}"
        elif tname == 'PolyAT':
            line += f" POLY_AT N{ev['note']} V{ev['pressure']}"
        elif tname == 'ChAfter':
            line += f" CH_AFTER N{ev['pressure']}"
        elif tname == 'PitchBend':
            val14 = ev['pitch']
            lsb = val14 & 0x7F
            msb = (val14 >> 7) & 0x7F
            line += f" PW N{lsb} V{msb}"
        output_rows.append(line)

    lines.append("CH 0")
    lines.extend(output_rows)
    lines.append("END_CH")

    lines.append("END_TRACK")
    lines.append("END_OF_FILE")
    return lines

def hid_to_txt_v3(hid_in, txt_out):
    with open(hid_in, "rb") as f:
        data = f.read()

    hid_struct = parse_hid_v3(data)
    lines = build_compact_text(hid_struct)

    with open(txt_out, "w", encoding="utf-8") as fw:
        for ln in lines:
            fw.write(ln + "\n")

    print(f"{hid_in} => {txt_out} 转换完成 (v3 HID->TXT, 无损互转)")

def main():
    if len(sys.argv) != 3:
        print("用法:")
        print("  python hid_txt.py <input.hid> <output.txt>")
        sys.exit(1)
    inp, outp = sys.argv[1], sys.argv[2]
    hid_to_txt_v3(inp, outp)

if __name__ == "__main__":
    main()