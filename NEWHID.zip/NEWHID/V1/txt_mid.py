#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
txt_mid.py

功能: 将精简文本格式(.txt)转换回标准MIDI文件(.mid)。
用法:
    python txt_mid.py <input.txt> <output.mid>
"""

import sys
import struct

##########################
# 公共工具函数
##########################

def read_varlen(data, offset):
    val, c = 0, 0
    while True:
        b = data[offset + c]
        c += 1
        val = (val << 7) | (b & 0x7F)
        if b < 0x80:
            break
    return val, c

def encode_varlen(value):
    if value == 0:
        return [0]
    buf = []
    while value > 0:
        buf.insert(0, (value & 0x7F) | 0x80)
        value >>= 7
    buf[-1] &= 0x7F
    return buf

##########################
# 文本 -> 内部结构
##########################

def from_compact_in_memory(lines):
    midi = {
        "header": {},
        "tracks": []
    }
    current_track_events = None
    track_index = -1
    channel_states = {}
    open_notes_map = {}
    tempo_list = []

    def ensure_channel_state(ch):
        if ch not in channel_states:
            channel_states[ch] = {
                'abs_time': 0,
                'last_type': None,
                'last_params': {}
            }
        return channel_states[ch]
    
    for line in lines:
        if line.startswith("HEADER"):
            f, n, d = map(int, line.split()[1:])
            midi["header"].update({"format": f, "ntrks": n, "division": d})
            continue
        if line.startswith("TEMPO"):
            parts = line.split()
            if len(parts) == 3:
                abs_t = int(parts[1])
                bpm = float(parts[2])
                tempo_list.append((abs_t, bpm))
            continue
        if line.startswith("TRACK"):
            track_index += 1
            if current_track_events:
                midi["tracks"].append(current_track_events)
            current_track_events = []
            channel_states = {}
            open_notes_map = {}
            continue
        if line == "END_TRACK":
            if current_track_events:
                midi["tracks"].append(current_track_events)
            current_track_events = None
            continue
        if line == "END_OF_FILE":
            break
        
        if current_track_events is None:
            continue
        
        if line.startswith("CH "):
            ch = int(line.split()[1])
            ensure_channel_state(ch)
            continue
        
        if line == "CH_META_SYSEX":
            ensure_channel_state(-1)
            continue
        
        if line == "END_CH":
            continue
        
        if line.startswith("T"):
            parts = line.split(maxsplit=1)
            dt = int(parts[0][1:])
            remainder = parts[1].strip() if len(parts)>1 else ""
            
            cands = list(channel_states.keys())
            if not cands:
                ch = 0
                ensure_channel_state(ch)
            else:
                ch = cands[-1]
            
            st = ensure_channel_state(ch)
            st['abs_time'] += dt
            abs_t = st['abs_time']
            last_type = st['last_type']
            last_params = dict(st['last_params'])
            
            if not remainder:
                cur_type = last_type
                cur_params = last_params
            else:
                tokens = remainder.split()
                possible_type = tokens[0].upper()
                known_types = ("CC","PC","N","NOTE_OFF","POLY_AT","CH_AFTER","PW")
                if possible_type in known_types or possible_type.startswith("META_0X") \
                   or possible_type.startswith("SYSEX") or possible_type.startswith("UNKNOWN_0X"):
                    cur_type = possible_type
                    param_tokens = tokens[1:]
                else:
                    cur_type = last_type
                    param_tokens = tokens
                cur_params = dict(last_params)
                for tk in param_tokens:
                    if tk and tk[0] in ('N','V','D'):
                        val = tk[1:]
                        if val.lstrip("+-").isdigit():
                            cur_params[tk[0]] = int(val)
            
            st['last_type'] = cur_type
            st['last_params'] = cur_params
            
            if not cur_type:
                continue
            
            if cur_type.startswith("META_0X"):
                meta_type = int(cur_type[7:9],16)
                hexdata = ""
                if remainder.startswith("META_0x"):
                    sp = remainder.split(maxsplit=1)
                    if len(sp)>1:
                        hexdata = sp[1].replace(" ","")
                data_bytes = bytes.fromhex(hexdata) if hexdata else b""
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"meta","meta_type":meta_type,"meta_data":data_bytes
                }))
            elif cur_type == "SYSEX":
                hexdata = ""
                if remainder.startswith("SYSEX"):
                    sp = remainder.split(maxsplit=1)
                    if len(sp)>1:
                        hexdata = sp[1].replace(" ","")
                data_bytes = bytes.fromhex(hexdata) if hexdata else b""
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"sysex","sysex_data":data_bytes
                }))
            elif cur_type.startswith("UNKNOWN_0X"):
                sb = int(cur_type[9:11],16)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"unknown","status_byte":sb
                }))
            elif cur_type == "N":
                n_ = cur_params.get('N',60)
                v_ = cur_params.get('V',127)
                d_ = cur_params.get('D',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0x9,"channel":ch,
                    "param1":n_,"param2":v_
                }))
                off_t = abs_t + d_
                current_track_events.append((off_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0x8,"channel":ch,
                    "param1":n_,"param2":64
                }))
            elif cur_type == "CC":
                n_ = cur_params.get('N',0)
                v_ = cur_params.get('V',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0xB,"channel":ch,
                    "param1":n_,"param2":v_
                }))
            elif cur_type == "PC":
                n_ = cur_params.get('N',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0xC,"channel":ch,
                    "param1":n_
                }))
            elif cur_type == "PW":
                n_ = cur_params.get('N',0)
                v_ = cur_params.get('V',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0xE,"channel":ch,
                    "param1":n_,"param2":v_
                }))
            elif cur_type == "NOTE_OFF":
                n_ = cur_params.get('N',60)
                v_ = cur_params.get('V',0)
                if (ch,n_) not in open_notes_map:
                    current_track_events.append((0, {
                        "delta_time":0,
                        "type":"channel","event_type":0x9,"channel":ch,
                        "param1":n_,"param2":64
                    }))
                    open_notes_map[(ch,n_)] = (0,64)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0x8,"channel":ch,
                    "param1":n_,"param2":v_
                }))
                if (ch,n_) in open_notes_map:
                    del open_notes_map[(ch,n_)]
            elif cur_type == "POLY_AT":
                n_ = cur_params.get('N',60)
                v_ = cur_params.get('V',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0xA,"channel":ch,
                    "param1":n_,"param2":v_
                }))
            elif cur_type == "CH_AFTER":
                n_ = cur_params.get('N',0)
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"channel","event_type":0xD,"channel":ch,
                    "param1":n_
                }))
            else:
                current_track_events.append((abs_t, {
                    "delta_time":0,
                    "type":"unknown","status_byte":0xFF
                }))
    
    if current_track_events and current_track_events not in midi["tracks"]:
        midi["tracks"].append(current_track_events)
    if len(midi["tracks"]) == 0:
        midi["tracks"].append([])
    
    merged_track0 = list(midi["tracks"][0])
    for (abs_t, bpm) in tempo_list:
        mpqn = int(round(60000000.0 / bpm))
        data_bytes = mpqn.to_bytes(3, byteorder="big", signed=False)
        merged_track0.append((abs_t, {
            "delta_time":0,
            "type":"meta",
            "meta_type":0x51,
            "meta_data":data_bytes
        }))
    merged_track0.sort(key=lambda x: x[0])
    out_track0 = []
    lastt = 0
    for (abs_t, e) in merged_track0:
        dt = abs_t - lastt
        lastt = abs_t
        e2 = e.copy()
        e2["delta_time"] = dt
        out_track0.append(e2)
    midi["tracks"][0] = out_track0
    
    for i in range(1, len(midi["tracks"])):
        evlist = midi["tracks"][i]
        evlist.sort(key=lambda x: x[0])
        out = []
        lastt = 0
        for (abs_t, e) in evlist:
            dt = abs_t - lastt
            lastt = abs_t
            e2 = e.copy()
            e2["delta_time"] = dt
            out.append(e2)
        midi["tracks"][i] = out
    
    return midi

##########################
# 还原MIDI二进制
##########################

def rebuild_midi_from_parsed(midi):
    hdr = b'MThd' + struct.pack(">I", 6)
    hdr += struct.pack(">HHH",
        midi["header"]["format"],
        len(midi["tracks"]),
        midi["header"]["division"]
    )
    chunks = []
    for trk in midi["tracks"]:
        buf = bytearray()
        rstat = None
        for ev in trk:
            buf.extend(encode_varlen(ev["delta_time"]))
            if ev["type"] == "meta":
                buf += bytes([0xFF, ev["meta_type"]])
                buf += bytes(encode_varlen(len(ev["meta_data"]))) + ev["meta_data"]
                rstat = 0xFF
            elif ev["type"] == "sysex":
                sb = ev.get("status_byte", 0xF0)
                buf.append(sb)
                buf += bytes(encode_varlen(len(ev["sysex_data"]))) + ev["sysex_data"]
                rstat = sb
            elif ev["type"] == "channel":
                st = (ev["event_type"] << 4) | ev["channel"]
                if st != rstat:
                    buf.append(st)
                    rstat = st
                et = ev["event_type"]
                if et in (0x8,0x9,0xA,0xB,0xE):
                    buf += bytes([ev["param1"], ev["param2"]])
                elif et in (0xC,0xD):
                    buf.append(ev["param1"])
            else:
                sb = ev.get("status_byte", 0xFF)
                if sb != rstat:
                    buf.append(sb)
                    rstat = sb
        buf += b"\x00\xFF\x2F\x00"
        chunks.append(b'MTrk' + struct.pack(">I", len(buf)) + buf)
    return hdr + b"".join(chunks)

##########################
# 文件接口
##########################

def compact2midi(txt_in, mid_out):
    with open(txt_in, "r", encoding="utf-8") as f:
        lines = [x.strip() for x in f if x.strip()]
    m = from_compact_in_memory(lines)
    data = rebuild_midi_from_parsed(m)
    with open(mid_out, "wb") as f:
        f.write(data)
    print(f"{txt_in} => {mid_out} 重建MIDI完成（保留BPM信息）")

##########################
# 主函数
##########################

def main():
    if len(sys.argv) != 3:
        print("用法:")
        print("  python txt_mid.py <input.txt> <output.mid>")
        sys.exit(1)
    inp, outp = sys.argv[1], sys.argv[2]
    compact2midi(inp, outp)

if __name__ == "__main__":
    main()