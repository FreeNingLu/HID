#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
mid_txt.py

功能: 将标准MIDI文件(.mid)转换为精简文本格式(.txt)。
用法:
    python mid_txt.py <input.mid> <output.txt>
"""

import sys
import struct

##########################
# 公共部分：常用工具函数
##########################

def read_varlen(data, offset):
    """
    从 data[offset:] 读取一个VLQ（Variable Length Quantity）变长整数。
    返回二元组 (value, 消费字节数).
    """
    val, c = 0, 0
    while True:
        b = data[offset + c]
        c += 1
        val = (val << 7) | (b & 0x7F)
        if b < 0x80:
            break
    return val, c

def encode_varlen(value):
    """
    将整数value编码为VLQ格式字节列表。
    若value=0，则编码成单字节[0]。
    """
    if value == 0:
        return [0]
    buf = []
    while value > 0:
        buf.insert(0, (value & 0x7F) | 0x80)
        value >>= 7
    buf[-1] &= 0x7F
    return buf

##########################
# MIDI -> 内部结构
##########################

def parse_midi(data):
    """
    解析标准MIDI文件二进制数据，返回内部结构:
    {
      "header": {"format":..., "ntrks":..., "division":...},
      "tracks": [
         [  # 事件列表
            { "delta_time":..., "type":..., ... },
            ...
         ],
         ...
      ]
    }
    """
    if data[:4] != b'MThd':
        raise ValueError("Not a valid MIDI file.")
    hl = struct.unpack(">I", data[4:8])[0]
    fmt, ntrks, div = struct.unpack(">HHH", data[8:14])
    
    res = {
        "header": {
            "format": fmt,
            "ntrks": ntrks,
            "division": div
        },
        "tracks": []
    }
    
    offset = 8 + hl
    for _ in range(ntrks):
        if data[offset:offset+4] != b'MTrk':
            raise ValueError("Missing MTrk.")
        tl = struct.unpack(">I", data[offset+4:offset+8])[0]
        trk = data[offset+8:offset+8+tl]
        offset += 8 + tl
        
        idx = 0
        rstat = None
        events = []
        
        while idx < tl:
            dt, dc = read_varlen(trk, idx)
            idx += dc
            if idx >= tl:
                break
            b = trk[idx]
            
            if b >= 0x80:
                rstat = b
                idx += 1
            status = rstat
            
            if status == 0xFF:
                mtype = trk[idx]
                idx += 1
                ln, lc = read_varlen(trk, idx)
                idx += lc
                mdat = trk[idx:idx+ln]
                idx += ln
                events.append({
                    "delta_time": dt,
                    "type": "meta",
                    "meta_type": mtype,
                    "meta_data": mdat
                })
            elif status in (0xF0, 0xF7):
                ln, lc = read_varlen(trk, idx)
                idx += lc
                sdat = trk[idx:idx+ln]
                idx += ln
                events.append({
                    "delta_time": dt,
                    "type": "sysex",
                    "sysex_data": sdat,
                    "status_byte": status
                })
            else:
                et = (status >> 4) & 0xF
                ch = status & 0xF
                if et in (0x8,0x9,0xA,0xB,0xE):
                    d1, d2 = trk[idx], trk[idx+1]
                    idx += 2
                    events.append({
                        "delta_time": dt,
                        "type": "channel",
                        "event_type": et,
                        "channel": ch,
                        "param1": d1,
                        "param2": d2
                    })
                elif et in (0xC,0xD):
                    d1 = trk[idx]
                    idx += 1
                    events.append({
                        "delta_time": dt,
                        "type": "channel",
                        "event_type": et,
                        "channel": ch,
                        "param1": d1
                    })
                else:
                    events.append({
                        "delta_time": dt,
                        "type": "unknown",
                        "status_byte": status
                    })
        res["tracks"].append(events)
    return res

##########################
# MIDI -> 精简文本
##########################

def to_compact_in_memory(midi):
    """
    将 MIDI内部结构 转为精简文本行列表。
    """
    lines = [
        f"HEADER {midi['header']['format']} {midi['header']['ntrks']} {midi['header']['division']}"
    ]
    
    tempo_events = []
    for i, events in enumerate(midi["tracks"]):
        abs_t = 0
        for ev in events:
            abs_t += ev["delta_time"]
            if ev["type"] == "meta" and ev["meta_type"] == 0x51:
                mpqn = int.from_bytes(ev["meta_data"], byteorder="big")
                bpm = 60000000.0 / mpqn
                tempo_events.append((abs_t, bpm, i))
    tempo_events.sort(key=lambda x: x[0])
    for (t, bpm, track_idx) in tempo_events:
        lines.append(f"TEMPO {t} {round(bpm, 4)}")
    
    for i, events in enumerate(midi["tracks"]):
        lines.append(f"TRACK {i}")
        abs_t = 0
        on_notes = {}
        chmap = {}
        
        for ev in events:
            dt = ev["delta_time"]
            abs_t += dt
            if ev["type"] == "meta" and ev["meta_type"] == 0x51:
                continue
            if ev["type"] == "channel":
                c = ev["channel"]
                et = ev["event_type"]
                p1 = ev.get("param1",0)
                p2 = ev.get("param2",0)
                if et == 0x9 and p2 != 0:
                    on_notes[(c,p1)] = (abs_t, p2)
                elif (et == 0x9 and p2 == 0) or et == 0x8:
                    if (c,p1) in on_notes:
                        st, vv = on_notes.pop((c,p1))
                        _add(chmap, c, st, True, dict(note=p1,velocity=vv,duration=abs_t-st))
                    else:
                        _add(chmap, c, abs_t, False, f"NOTE_OFF N{p1} V{p2}")
                else:
                    _add(chmap, c, abs_t, False, _chan2txt(et,p1,p2))
            elif ev["type"] == "meta":
                _add(chmap, -1, abs_t, False, f"META_0x{ev['meta_type']:02X} {ev['meta_data'].hex().upper()}")
            elif ev["type"] == "sysex":
                _add(chmap, -1, abs_t, False, f"SYSEX {ev['sysex_data'].hex().upper()}")
            else:
                sb = ev.get("status_byte", 0xFF)
                _add(chmap, -1, abs_t, False, f"UNKNOWN_0x{sb:02X}")
        
        for (c,n), (t,v) in on_notes.items():
            _add(chmap, c, t, True, dict(note=n,velocity=v,duration=0))
        
        lines += _chmap2lines_compressed(chmap)
        lines.append("END_TRACK")
    lines.append("END_OF_FILE")
    return lines

def _add(chmap, c, t, is_note, pld):
    if c not in chmap:
        chmap[c] = []
    chmap[c].append((t, is_note, pld))

def _chan2txt(et, p1, p2):
    if et == 0x9 and p2 == 0:
        return f"NOTE_OFF N{p1} V0"
    if et == 0x8:
        return f"NOTE_OFF N{p1} V{p2}"
    if et == 0xB:
        return f"CC N{p1} V{p2}"
    if et == 0xC:
        return f"PC N{p1}"
    if et == 0xE:
        return f"PW N{p1} V{p2}"
    if et == 0xA:
        return f"POLY_AT N{p1} V{p2}"
    if et == 0xD:
        return f"CH_AFTER N{p1}"
    return f"UNKNOWN_CH_EVENT_{et}"

def _chmap2lines_compressed(chmap):
    lines = []
    for c in sorted(chmap.keys(), key=lambda x: (x == -1, x)):
        lines.append("CH_META_SYSEX" if c == -1 else f"CH {c}")
        evs = sorted(chmap[c], key=lambda x: x[0])
        prev_t = 0
        last_type = None
        last_params = {}
        
        for (abs_t, is_note, payload) in evs:
            dt = abs_t - prev_t
            prev_t = abs_t
            if is_note:
                cur_type = "N"
                cur_params = {
                    'N': payload['note'],
                    'V': payload['velocity'],
                    'D': payload['duration']
                }
            else:
                cur_type, cur_params = _parse_payload_to_type_params(payload)
            
            line = f"T{dt}"
            if cur_type != last_type:
                line += " " + cur_type
                param_str = _build_param_str(cur_params)
                if param_str:
                    line += " " + param_str
                last_type = cur_type
                last_params = dict(cur_params)
            else:
                diff_params = {}
                for k,v in cur_params.items():
                    if v != last_params.get(k):
                        diff_params[k] = v
                if diff_params:
                    param_str = _build_param_str(diff_params)
                    if param_str:
                        line += " " + param_str
                    last_params.update(diff_params)
            lines.append(line)
        lines.append("END_CH")
    return lines

def _parse_payload_to_type_params(payload:str):
    parts = payload.split()
    if not parts:
        return ("UNKNOWN", {})
    evt_type = parts[0]
    if evt_type.startswith("META_0x") or evt_type.startswith("SYSEX") or evt_type.startswith("UNKNOWN_0x"):
        return (evt_type, {})
    known_labels = ("CC","PC","N","NOTE_OFF","POLY_AT","CH_AFTER","PW")
    if evt_type not in known_labels:
        # 可能是 "N60" 这样的形式
        if evt_type.startswith("N") and evt_type[1:].isdigit():
            return ("N", {'N': int(evt_type[1:]), 'V':0, 'D':0})
        return ("UNKNOWN", {})
    param_dict = {}
    for tk in parts[1:]:
        if tk[0] in ('N','V','D'):
            val = tk[1:]
            if val.lstrip("+-").isdigit():
                param_dict[tk[0]] = int(val)
    return (evt_type, param_dict)

def _build_param_str(params:dict):
    keys_order = ['N','V','D']
    out = []
    done = set()
    for k in keys_order:
        if k in params:
            out.append(f"{k}{params[k]}")
            done.add(k)
    for k in params:
        if k not in done:
            out.append(f"{k}{params[k]}")
    return " ".join(out)

##########################
# 文件接口
##########################

def midi2compact(mid_in, txt_out):
    with open(mid_in, "rb") as f:
        data = f.read()
    m = parse_midi(data)
    lines = to_compact_in_memory(m)
    with open(txt_out, "w", encoding="utf-8") as f:
        for ln in lines:
            f.write(ln + "\n")
    print(f"{mid_in} => {txt_out} 转换完成（MIDI->精简文本，含BPM信息）")

##########################
# 主函数入口
##########################

def main():
    if len(sys.argv) != 3:
        print("用法:")
        print("  python mid_txt.py <input.mid> <output.txt>")
        sys.exit(1)
    
    inp, outp = sys.argv[1], sys.argv[2]
    midi2compact(inp, outp)

if __name__ == "__main__":
    main()