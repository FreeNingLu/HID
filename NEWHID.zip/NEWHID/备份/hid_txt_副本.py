#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
hid_txt.py

功能: 将 v3版自定义HID二进制(.hid) 转换回精简文本格式(.txt)。
     兼容无损互转，包括 Bundle(0x8) 拆包、PitchBend(0x7+0xF) 等。
用法:
    python hid_txt.py <input.hid> <output.txt>
"""

import sys
import struct

try:
    import zstandard as zstd
    HAS_ZSTD = True
except ImportError:
    HAS_ZSTD = False

def parse_hid_v3(data):
    """
    解析HID v3格式，支持:
      - 单轨(ntrks=1) 轨道区
      - use_zstd=1 时(文件头 flags.bit2=1)，若轨道区首字节=0x7A => 需解压
      - 逐字节读事件: 普通 4字节大端(Delay/Note/CC/...)，或 0x8 Bundle 后跟 n×3字节
      - PitchBend(0x7 + 0xF) 合并成一个 'PitchBend'
      - 末尾 tempo 块(2 + tempo_count×8 字节)，包含若干 (abs_t, mpqn)
        => bpm = 60000000 / mpqn
    返回结构:
      {
        'ntrks': ...,
        'division': ...,
        'shift': ...,
        'tracks': [ [evt, evt, ...] ],  # (本示例只实现单轨)
        'tempos': [(abs_t, bpm), ...]
      }
    evt 的字段:
      'abs_t', 'type' (字符串: 'Note','CC','PC','PitchBend','PolyAT','ChAfter'等),
      以及 'note','velocity','duration','cc_num','cc_val','pitch','pressure'...
    """
    # 1) 检查文件头
    if len(data) < 8 or data[:3] != b'HID':
        raise ValueError("文件头不合法, 非'HID'开头")
    version = data[3]
    if version != 0x03:
        raise ValueError(f"版本号不符, 需要v3, 读到{version}")

    ntrks = data[4]
    division = struct.unpack(">H", data[5:7])[0]
    flags = data[7]

    shift = flags & 0x3        # 低2bit => shift
    use_zstd = (flags >> 2) & 0x1  # 第3bit => zstd压缩标志

    # 仅示例: ntrks=1
    if ntrks != 1:
        print("[警告] 目前只实现单轨解析, ntrks>1 可能解析错误或不支持")

    # 2) 解析 tempo 块（文件末尾）
    if len(data) < 10:
        raise ValueError("文件过短, 不含 tempo 块")
    # 最后2字节 => tempo_count
    tempo_count = struct.unpack(">H", data[-2:])[0]
    tempo_block_size = 2 + tempo_count * 8
    if tempo_block_size > (len(data) - 8):
        raise ValueError("tempo块尺寸异常")

    tempo_block_offset = len(data) - tempo_block_size

    # 3) 轨道区在 [8, tempo_block_offset)
    track_region = data[8 : tempo_block_offset]

    # 如果 use_zstd=1 并且第一个字节=0x7A，则需要解压
    if use_zstd == 1 and len(track_region) > 0 and track_region[0] == 0x7A:
        cdata = track_region[1:]
        if not HAS_ZSTD:
            raise RuntimeError("文件包含Zstd压缩数据, 但未安装 zstandard 库!")
        dctx = zstd.ZstdDecompressor()
        track_decompressed = dctx.decompress(cdata)
    else:
        track_decompressed = track_region

    # 4) 解析轨道事件(已解压后的字节流)
    events = decode_track_data(track_decompressed, shift)

    # 5) 解析 tempo 块
    tempos = []
    offset_t = tempo_block_offset + 2
    for _ in range(tempo_count):
        abs_t = struct.unpack(">I", data[offset_t : offset_t+4])[0]
        offset_t += 4
        mpqn = struct.unpack(">I", data[offset_t : offset_t+4])[0]
        offset_t += 4
        if mpqn < 1:
            mpqn = 1
        bpm = 60000000.0 / mpqn
        tempos.append((abs_t, bpm))

    return {
        'ntrks': ntrks,
        'division': division,
        'shift': shift,
        'tracks': [events],   # 只做单轨
        'tempos': tempos
    }

def decode_track_data(track_bytes, shift):
    """
    逐字节解析轨道区(已解压后):
      - 读 4字节 => event_type(4bit), channel(4bit), note(7bit), velocity(7bit), extra(10bit)
      - 若 event_type=0x8(Bundle)，则后跟 (extra+1)*3 字节 => 拆分子事件
      - PitchBend(0x7) 后紧跟 0xF (高4bit)
      - Delay(0x0) => abs_t += extra
      - Note => 记录 abs_t, type='Note', note/velocity/duration=extra
      - 最后把 abs_t/duration 根据 shift 左移还原
    """
    idx = 0
    length = len(track_bytes)
    abs_t = 0
    events = []

    while idx + 4 <= length:
        w = struct.unpack_from(">I", track_bytes, idx)[0]
        idx += 4

        et = (w >> 28) & 0xF
        ch = (w >> 24) & 0xF
        note = (w >> 17) & 0x7F
        vel  = (w >> 10) & 0x7F
        ex   = w & 0x3FF

        if et == 0x0:  # Delay
            abs_t += ex
            continue

        elif et == 0x1:  # Tie(不常用) => 此处示例忽略
            continue

        elif et == 0x2:  # Note
            events.append({
                'abs_t': abs_t,
                'type': 'Note',
                'channel': ch,
                'note': note,
                'velocity': vel,
                'duration': ex
            })

        elif et == 0x3:  # CC
            events.append({
                'abs_t': abs_t,
                'type': 'CC',
                'channel': ch,
                'cc_num': note,
                'cc_val': ex
            })

        elif et == 0x4:  # PC
            events.append({
                'abs_t': abs_t,
                'type': 'PC',
                'channel': ch,
                'pc_num': ex
            })

        elif et == 0x5:  # PolyAT
            events.append({
                'abs_t': abs_t,
                'type': 'PolyAT',
                'channel': ch,
                'note': note,
                'pressure': ex
            })

        elif et == 0x6:  # ChAfter
            events.append({
                'abs_t': abs_t,
                'type': 'ChAfter',
                'channel': ch,
                'pressure': ex
            })

        elif et == 0x7:
            # PitchBend低10bit => 需紧跟 0xF(扩展槽) 读高4bit
            if idx + 4 <= length:
                w2 = struct.unpack_from(">I", track_bytes, idx)[0]
                et2 = (w2 >> 28) & 0xF
                ex2 = w2 & 0x3FF
                if et2 == 0xF:
                    idx += 4
                    high4 = ex2 & 0xF
                    val14 = (high4 << 10) | ex
                    events.append({
                        'abs_t': abs_t,
                        'type': 'PitchBend',
                        'channel': ch,
                        'pitch': val14
                    })
                else:
                    raise ValueError("PitchBend后未匹配0xF扩展槽")
            else:
                raise ValueError("PitchBend后数据不足")

        elif et == 0x8:
            # Bundle => extra+1 条事件（子事件3字节）
            n_bundle = ex + 1
            needed = 3 * n_bundle
            if idx + needed > length:
                raise ValueError("Bundle后数据不足, 无法读取子包")
            sub_data = track_bytes[idx : idx+needed]
            idx += needed
            # 解析子事件
            sub_idx = 0
            for _ in range(n_bundle):
                b1 = sub_data[sub_idx]
                b2 = sub_data[sub_idx+1]
                b3 = sub_data[sub_idx+2]
                sub_idx += 3
                val24 = (b1 << 16) | (b2 << 8) | b3
                note7 = (val24 >> 17) & 0x7F
                vel7  = (val24 >> 10) & 0x7F
                ex10  = val24 & 0x3FF

                # 只考虑打包的三种类型: Note(0x2), CC(0x3), PB(0x7)
                # 但从写端看, event_type=et=0x2 或0x3 或0x7, 这里才会打包
                # => 这里必须分别拆分
                if et == 0x2:
                    # Note
                    events.append({
                        'abs_t': abs_t,
                        'type': 'Note',
                        'channel': ch,
                        'note': note7,
                        'velocity': vel7,
                        'duration': ex10
                    })
                elif et == 0x3:
                    # CC
                    events.append({
                        'abs_t': abs_t,
                        'type': 'CC',
                        'channel': ch,
                        'cc_num': note7,
                        'cc_val': ex10
                    })
                elif et == 0x7:
                    # Bundle打包的PitchBend(默认高4bit=0)
                    val14 = ex10  # (低10bit + 0)
                    events.append({
                        'abs_t': abs_t,
                        'type': 'PitchBend',
                        'channel': ch,
                        'pitch': val14
                    })
                else:
                    raise ValueError("Bundle事件类型未知 or 未实现")

        else:
            # 0x9..0xE 或 0xF(除PB扩展外) => 暂不支持
            pass

    # 最后把 shift 还原: abs_t, duration(对 Note), 其余可能无须 shift
    for ev in events:
        ev['abs_t'] <<= shift
        if ev['type'] == 'Note':
            ev['duration'] <<= shift

    return events

def build_compact_text(hid_struct):
    """
    将解析后结构 => 精简 txt 形式:
      HEADER 0 nTrks division
      TEMPO abs_t bpm
      TRACK 0
         CH 0
           T<delta> <type> <params...>
         END_CH
      END_TRACK
      END_OF_FILE
    """
    lines = []
    lines.append(f"HEADER 0 {hid_struct['ntrks']} {hid_struct['division']}")

    # TEMPO lines
    for (abs_t, bpm) in sorted(hid_struct['tempos'], key=lambda x: x[0]):
        lines.append(f"TEMPO {abs_t} {round(bpm, 4)}")

    lines.append("TRACK 0")

    events = hid_struct['tracks'][0]
    # 将绝对时间 -> delta
    sorted_ev = sorted(events, key=lambda x: x['abs_t'])
    prev_t = 0
    output_rows = []

    for ev in sorted_ev:
        dt = ev['abs_t'] - prev_t
        prev_t = ev['abs_t']
        line = f"T{dt}"
        tname = ev['type']
        if tname == 'Note':
            # "N N<note> V<vel> D<dur>"
            line += f" N N{ev['note']} V{ev['velocity']} D{ev['duration']}"
        elif tname == 'CC':
            line += f" CC N{ev['cc_num']} V{ev['cc_val']}"
        elif tname == 'PC':
            line += f" PC N{ev['pc_num']}"
        elif tname == 'PolyAT':
            line += f" POLY_AT N{ev['note']} V{ev['pressure']}"
        elif tname == 'ChAfter':
            line += f" CH_AFTER N{ev['pressure']}"
        elif tname == 'PitchBend':
            val14 = ev['pitch']
            lsb = val14 & 0x7F
            msb = (val14 >> 7) & 0x7F
            line += f" PW N{lsb} V{msb}"
        output_rows.append(line)

    # 默认只用通道0
    lines.append("CH 0")
    lines.extend(output_rows)
    lines.append("END_CH")

    lines.append("END_TRACK")
    lines.append("END_OF_FILE")
    return lines

def hid_to_txt_v3(hid_in, txt_out):
    """
    读入 HID v3 => 解析结构 => 转成文本
    """
    with open(hid_in, "rb") as f:
        data = f.read()

    hid_struct = parse_hid_v3(data)
    lines = build_compact_text(hid_struct)

    with open(txt_out, "w", encoding="utf-8") as fw:
        for ln in lines:
            fw.write(ln + "\n")

    print(f"{hid_in} => {txt_out} 转换完成 (v3 HID->TXT, 无损互转)")

def main():
    if len(sys.argv) != 3:
        print("用法:")
        print("  python hid_txt.py <input.hid> <output.txt>")
        sys.exit(1)
    inp, outp = sys.argv[1], sys.argv[2]
    hid_to_txt_v3(inp, outp)

if __name__ == "__main__":
    main()