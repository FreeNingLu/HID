#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import sys
import struct

def read_varlen(data, offset):
    """
    从 data[offset:] 读取一个VLQ（Variable-Length Quantity）变长整数。
    返回 (value, 消费字节数)。
    """
    value = 0
    consumed = 0
    while True:
        if offset + consumed >= len(data):
            raise ValueError("Unexpected end of data while reading varlen.")
        b = data[offset + consumed]
        consumed += 1
        value = (value << 7) | (b & 0x7F)
        if b < 0x80:
            break
    return value, consumed

def parse_track_events(track_data):
    """
    给定一个Track区块的原始字节序列，解析其中的MIDI事件列表。
    采用正确的跑状态(Running Status)逻辑，避免把delta=0或别的字节误判为note=0等。
    
    返回一个列表: [ { "delta_time":..., "abs_time":..., "type":..., ... }, ... ]
    """
    events = []
    idx = 0
    running_status = None
    abs_time = 0

    while idx < len(track_data):
        # 1) 读取delta-time (变长整数)
        delta, delta_len = read_varlen(track_data, idx)
        idx += delta_len
        abs_time += delta

        if idx >= len(track_data):
            # 没有更多数据了
            break

        # 2) 检查下一字节是否 >= 0x80 (是否新的状态字节)
        status_byte = track_data[idx]
        if status_byte >= 0x80:
            # 是新的状态字节
            running_status = status_byte
            idx += 1
        else:
            # 没有新的状态字节 => 使用上一次 running_status
            if running_status is None:
                # 这意味着数据格式不合法
                raise ValueError("No running status but found data byte (possible malformed MIDI).")
            status_byte = running_status

        # 3) 根据 status_byte 判断事件类型
        if 0x80 <= status_byte < 0xF0:
            # ===== 通道事件 =====
            event_type = (status_byte >> 4) & 0x0F
            channel = status_byte & 0x0F

            if event_type in (0x8, 0x9, 0xA, 0xB, 0xE):
                # 需要 2 个参数字节
                if idx + 1 >= len(track_data):
                    raise ValueError("Not enough data for channel event param2.")
                p1 = track_data[idx]
                p2 = track_data[idx+1]
                idx += 2
                events.append({
                    "delta_time": delta,
                    "abs_time": abs_time,
                    "status": status_byte,
                    "type": "channel",
                    "event_type": event_type,
                    "channel": channel,
                    "param1": p1,
                    "param2": p2
                })
            elif event_type in (0xC, 0xD):
                # 需要 1 个参数字节
                if idx >= len(track_data):
                    raise ValueError("Not enough data for channel event param1.")
                p1 = track_data[idx]
                idx += 1
                events.append({
                    "delta_time": delta,
                    "abs_time": abs_time,
                    "status": status_byte,
                    "type": "channel",
                    "event_type": event_type,
                    "channel": channel,
                    "param1": p1
                })
            else:
                # 理论上不会到这里，但以防万一
                events.append({
                    "delta_time": delta,
                    "abs_time": abs_time,
                    "status": status_byte,
                    "type": "unknown_channel"
                })

        elif status_byte == 0xFF:
            # ===== Meta事件 =====
            if idx >= len(track_data):
                raise ValueError("Missing meta type byte.")
            meta_type = track_data[idx]
            idx += 1
            length, length_len = read_varlen(track_data, idx)
            idx += length_len

            if idx + length > len(track_data):
                raise ValueError("Not enough data for meta event content.")
            meta_data = track_data[idx:idx+length]
            idx += length

            events.append({
                "delta_time": delta,
                "abs_time": abs_time,
                "status": 0xFF,
                "type": "meta",
                "meta_type": meta_type,
                "meta_data": meta_data
            })

        elif status_byte in (0xF0, 0xF7):
            # ===== SysEx事件 =====
            length, length_len = read_varlen(track_data, idx)
            idx += length_len
            if idx + length > len(track_data):
                raise ValueError("Not enough data for sysex event.")
            sdat = track_data[idx:idx+length]
            idx += length
            events.append({
                "delta_time": delta,
                "abs_time": abs_time,
                "status": status_byte,
                "type": "sysex",
                "sysex_data": sdat
            })

        else:
            # 其它F类事件(如0xF1,0xF2,0xF3,0xF8...等)
            # 在标准MIDI文件的Track Chunk里不常见，这里简单归为system
            events.append({
                "delta_time": delta,
                "abs_time": abs_time,
                "status": status_byte,
                "type": "system_or_unknown"
            })

    return events

def parse_midi(filename):
    """
    解析标准MIDI文件，返回结构:
    {
      "format": <int>,
      "ntrks": <int>,
      "division": <int>,
      "tracks": [
          [ {事件1}, {事件2}, ... ],
          ...
      ]
    }
    """
    with open(filename, "rb") as f:
        data = f.read()

    # 1) 检查文件头 MThd
    if data[0:4] != b'MThd':
        raise ValueError("Not a valid MIDI file (missing MThd).")

    # 头部长度（通常=6）
    header_len = struct.unpack(">I", data[4:8])[0]
    if len(data) < 8 + header_len:
        raise ValueError("MIDI header chunk is incomplete.")

    # 格式, track数, division
    fmt, ntrks, division = struct.unpack(">HHH", data[8:14])

    # 跳过头部剩余部分
    offset = 8 + header_len

    # 2) 解析后续每个 MTrk
    tracks = []
    for i in range(ntrks):
        if data[offset:offset+4] != b'MTrk':
            raise ValueError(f"Track {i} missing MTrk header.")
        track_len = struct.unpack(">I", data[offset+4:offset+8])[0]
        offset += 8
        track_data = data[offset : offset + track_len]
        offset += track_len

        # 用我们的函数解析Track
        events = parse_track_events(track_data)
        tracks.append(events)

    return {
        "format": fmt,
        "ntrks": ntrks,
        "division": division,
        "tracks": tracks
    }

def print_midi_info(midi):
    """
    简单打印 MIDI 的头信息及事件。
    """
    print(f"MIDI File Format: {midi['format']}")
    print(f"Number of Tracks: {midi['ntrks']}")
    print(f"Division (Ticks per Quarter): {midi['division']}")
    print("")

    for i, track_events in enumerate(midi["tracks"]):
        print(f"--- Track {i+1} ---")
        for ev in track_events:
            etype = ev["type"]
            atime = ev["abs_time"]
            if etype == "channel":
                ch = ev["channel"]
                e = ev["event_type"]
                if e == 0x9:
                    # Note On
                    note = ev["param1"]
                    vel = ev["param2"]
                    print(f"time={atime} NoteOn  ch={ch} note={note} vel={vel}")
                elif e == 0x8:
                    # Note Off
                    note = ev["param1"]
                    vel = ev["param2"]
                    print(f"time={atime} NoteOff ch={ch} note={note} vel={vel}")
                elif e == 0xB:
                    ctrl = ev["param1"]
                    val = ev["param2"]
                    print(f"time={atime} CC      ch={ch} control={ctrl} value={val}")
                elif e == 0xC:
                    prog = ev["param1"]
                    print(f"time={atime} Program ch={ch} program={prog}")
                else:
                    print(f"time={atime} ChannelEvent e=0x{e:X} ch={ch} param1={ev['param1']} param2={ev.get('param2','?')}")
            elif etype == "meta":
                mtype = ev["meta_type"]
                mdata = ev["meta_data"]
                print(f"time={atime} MetaEvent  type=0x{mtype:02X} len={len(mdata)} data={mdata}")
            elif etype == "sysex":
                sdata = ev["sysex_data"]
                print(f"time={atime} SysEx     len={len(sdata)} data={sdata}")
            else:
                print(f"time={atime} {etype} (status=0x{ev['status']:02X})")

        print("")

def main():
    if len(sys.argv) < 2:
        print("用法: python midi_rparse.py <input.mid>")
        sys.exit(1)

    midi_file = sys.argv[1]
    print(f"解析 MIDI 文件: {midi_file}")

    midi_data = parse_midi(midi_file)
    print_midi_info(midi_data)

if __name__ == "__main__":
    main()